package tryit;

public class TooManyBikesException extends Exception {

	TooManyBikesException(String msgText)
	{
		super(msgText);
	}
}
